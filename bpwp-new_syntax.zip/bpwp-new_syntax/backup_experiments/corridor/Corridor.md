# assumptions:
The common assumption we made for handling all problems in PDKB test cases
* The only movable agent is a
* The secret can only sense by agent a
* The secret needed to be sensed first then shared
* Agent a will only do action shout once