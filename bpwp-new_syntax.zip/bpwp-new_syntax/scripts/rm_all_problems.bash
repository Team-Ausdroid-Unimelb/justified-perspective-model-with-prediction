rm experiments/bbl/problem*.pddl
rm experiments/coin/problem*.pddl
rm experiments/spcoin/problem*.pddl
rm experiments/sn/problem*.pddl
rm experiments/corridor/problem*.pddl
rm experiments/grapevine/problem*.pddl

