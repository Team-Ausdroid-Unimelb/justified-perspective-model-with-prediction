cp experiments/bbl/original_problems/* experiments/bbl/
cp experiments/bbl/problem2_tt/* experiments/bbl/
cp experiments/bbl/problem3_ttt/* experiments/bbl/


cp experiments/coin/original_problems/* experiments/coin/
cp experiments/coin/problem2_tt/* experiments/coin/
cp experiments/coin/problem3_ttt/* experiments/coin/


cp experiments/spcoin/original_problems/* experiments/spcoin/
cp experiments/spcoin/problem2_tt/* experiments/spcoin/
cp experiments/spcoin/problem3_ttt/* experiments/spcoin/


cp experiments/sn/original_problems/* experiments/sn/
cp experiments/sn/problem2_tt/* experiments/sn/
cp experiments/sn/problem3_ttt/* experiments/sn/


cp experiments/corridor/original_problems/* experiments/corridor/
cp experiments/corridor/problem2_tt/* experiments/corridor/
cp experiments/corridor/problem3_ttt/* experiments/corridor/


cp experiments/grapevine/original_problems/* experiments/grapevine/
cp experiments/grapevine/problem2_tt/* experiments/grapevine/
cp experiments/grapevine/problem3_ttt/* experiments/grapevine/